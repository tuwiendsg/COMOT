#!/bin/bash

echo "war post_migrate"