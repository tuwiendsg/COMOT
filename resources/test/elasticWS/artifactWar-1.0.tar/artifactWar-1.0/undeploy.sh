#!/bin/bash

echo "war undeploy"

curl "http://tomcat:tomcat@localhost:8080/manager/text/undeploy?path=/testWS"

cd ..
rm -rf artifactWar-1.0