#!/bin/bash

echo "tomcat post_migrate"