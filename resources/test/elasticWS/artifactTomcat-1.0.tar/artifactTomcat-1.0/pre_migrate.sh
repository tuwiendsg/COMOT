#!/bin/bash

echo "tomcat pre_migrate"