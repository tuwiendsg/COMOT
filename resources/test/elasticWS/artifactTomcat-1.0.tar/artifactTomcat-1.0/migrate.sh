#!/bin/bash

echo "tomcat migrate"